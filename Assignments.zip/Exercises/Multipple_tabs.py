from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()

url1 = "https://jqueryui.com/"
url2 = "https://the-internet.herokuapp.com/"

driver.get(url1)
driver.switch_to.new_window()
driver.get(url2)

Number_of_tabs = len(driver.window_handles)
print(f"Total Number of Tabs are : '{Number_of_tabs}'")

Tab_values = driver.window_handles
print(f"The tab values are: '{Tab_values}'")

current_tab = driver.current_window_handle
First_tab = driver.window_handles[0]
if  current_tab != First_tab:
    driver.switch_to.window(First_tab)
    time.sleep(3)
else:
    print('Already in the first tab')
