import time
from selenium.webdriver.support.ui import Select
from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.get('file:///C:/Users/prnm/Documents/Experiment/sample%20html%20form.html')

driver.maximize_window()

dropdown_element = driver.find_element(By.ID,value="state")
select = Select(dropdown_element)
options_count = len(select.options)
print(options_count)


for option in select.options:
    print(option)

# Method 1: #Select dropdown element by text
# select.select_by_visible_text("Karnataka")


# Method 2 : #select dropdown element by index
# select.select_by_index(4)

# Method 3 : select dropdown element by option value
# # select.select_by_value("karnataka")

target_value = "karnataka"
for options in select.options:
    if options.text == target_value:
        print(f"target value'{target_value}' found")
        
        break 
        
    else:
        print(f"'{target_value}'Not found")

time.sleep(10)