import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains


driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://demo.automationtesting.in/Datepicker.html"
driver.get(url1)

# ActionChains are a way to automate low level interactions such as mouse movements, mouse button actions, key press, and context menu interactions.
actions = ActionChains(driver)

mouse_hover = driver.find_element(By.XPATH,value="//a[normalize-space()='SwitchTo']")
time.sleep(5)

actions.move_to_element(mouse_hover).perform()
time.sleep(10)

# Click the submenu item after hovering
frame_element = driver.find_element(By.XPATH, "//a[normalize-space()='Frames']")
frame_element.click()
time.sleep(10)
