import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://the-internet.herokuapp.com/horizontal_slider"
driver.get(url1)

actions = ActionChains(driver)

slider = driver.find_element(By.XPATH,value="//*[@id='content']/div/div/input")
actions.click_and_hold(slider).move_by_offset(100,0).release().perform()


time.sleep(10)
