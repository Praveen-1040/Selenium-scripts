import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://the-internet.herokuapp.com/nested_frames"
driver.get(url1)


# Switching to top frame
driver.switch_to.frame("frame-top") 

# Switching to Middle Frame
driver.switch_to.frame("frame-middle") 
content = driver.find_element(By.ID,value="content").text
print(content)


# Switching to default content (to exit from the above frame)
driver.switch_to.default_content()

# Switching to bottom frame 
driver.switch_to.frame("frame-bottom")
bottom_content = driver.find_element(By.TAG_NAME,value="body").text
print(bottom_content)
