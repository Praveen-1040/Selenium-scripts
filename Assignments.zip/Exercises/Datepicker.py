import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from datetime import datetime,timedelta
from selenium.webdriver import Keys


driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://www.globalsqa.com/demo-site/datepicker/#Simple%20Date%20Picker"
driver.get(url1)

unwanted = driver.find_element(By.CSS_SELECTOR,value=".close_img").click()
time.sleep(4)

#Enter into the frame 
framelo = driver.find_element(By.XPATH,value="//*[@id='post-2661']/div[2]/div/div/div[1]/p/iframe")
driver.switch_to.frame(framelo)

datefield = driver.find_element(By.ID,value="datepicker")
datefield.click()

current_date = datetime.now()

nextdate = current_date + timedelta(days=100)

previous_date = current_date+timedelta(days=-30)

formatted_date = nextdate.strftime("%m/%d/%y")

datefield.send_keys(formatted_date + Keys.TAB)
time.sleep(5)