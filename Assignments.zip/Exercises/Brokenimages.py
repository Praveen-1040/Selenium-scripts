from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import requests

driver = webdriver.Chrome()
driver.maximize_window()
login_url = "https://the-internet.herokuapp.com/broken_images"
driver.get(login_url)

images = driver.find_elements(By.TAG_NAME, value="img")
for image in images:
    src = image.get_attribute("src")
    if src:
        response = requests.get(src)
        if response.status_code != 200:
            print(f"The broken images are and the links is : '{src}'")
    else: 
        print("No broken images")