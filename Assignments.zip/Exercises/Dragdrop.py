import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains


driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://the-internet.herokuapp.com/drag_and_drop"
driver.get(url1)

src_element = driver.find_element(By.ID,value="column-a")
dest_element = driver.find_element(By.ID,value="column-b")

#ActionChains are a way to automate low level interactions such as mouse movements, mouse button actions, key press, and context menu interactions.
actions = ActionChains(driver)

actions.drag_and_drop(src_element,dest_element).perform()
time.sleep(5)