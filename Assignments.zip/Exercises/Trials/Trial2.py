import time
from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.maximize_window()

url1 = "https://jqueryui.com/"
driver.get(url1)

widget = driver.find_elements(By.CLASS_NAME,value="widget")

if widget:  # Ensure the list is not empty
    widget = widget[0]  # Access the first widget
    print(widget)
    # Find all links inside the widget
    links = widget.find_elements(By.TAG_NAME, value="a")

    hrefs = []
    for link in links:
        href = link.get_attribute("href")
        if href:
            hrefs.append(href)

    for href in hrefs:
        ##Open a new tab
        # The window.open() function creates a new browsing context (usually a new tab) and navigates it to the URL provided.
        # This is equivalent to right-clicking a link and selecting "Open Link in New Tab." 
        driver.execute_script(f"window.open('{href}','_blank');")

        # driver.switch_to.new_window(driver.window_handles[-1])

        driver.get(href)    #Open the URL 
        print(f"Opened URL:'{href}'")
        time.sleep(2)


print(hrefs)