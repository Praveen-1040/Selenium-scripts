import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()
driver.maximize_window()

url1 = "https://jqueryui.com/"

driver.get(url1)
draggable_element = driver.find_element(By.LINK_TEXT,value="Draggable")
href = draggable_element.get_attribute("href")
print(href)

##Open a new tab
# The window.open() function creates a new browsing context (usually a new tab) and navigates it to the URL provided.
# This is equivalent to right-clicking a link and selecting "Open Link in New Tab." 
driver.execute_script(f"window.open('{href}', '_blank');")

driver.switch_to.window(driver.window_handles[-1])

driver.get(href)
time.sleep(5)

driver.quit()


