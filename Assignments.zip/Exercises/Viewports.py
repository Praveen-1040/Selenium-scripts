import time
from selenium import webdriver
from selenium.webdriver.common.by import By


driver =webdriver.Chrome()
driver.get("https://www.google.co.in/")

viewports = [(414,896),(1024,1366),(768,1024),(412,914)]

for width,height in viewports:
    driver.set_window_size(width,height)
    time.sleep(5)

driver.close()