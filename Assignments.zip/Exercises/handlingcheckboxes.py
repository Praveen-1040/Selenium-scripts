import time
from typing import KeysView
from selenium import webdriver
from selenium.webdriver.common.by import By

# Initialize the browser
browser = webdriver.Chrome()

# Load the HTML form
browser.get("file:///C:/Users/prnm/Documents/Experiment/sample%20html%20form.html")
browser.maximize_window()

# Scroll to the bottom of the page
browser.execute_script("window.scrollTo(0, document.body.scrollHeight)")
checkboxes = browser.find_elements(By.XPATH,value="//input[@type='checkbox']")
for CB in checkboxes:
    CB.click()
    
time.sleep(10)
CB_count = 1

for CB in checkboxes:
    if CB.is_selected():
        CB_count+=1

if CB_count == 7:
    print("success")
else:
    print("failure")