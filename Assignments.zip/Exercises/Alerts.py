import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://the-internet.herokuapp.com/javascript_alerts"
driver.get(url1)

firstBtn = driver.find_element(By.XPATH,value="//*[@id='content']/div/ul/li[3]/button")
firstBtn.click()
time.sleep(3)

# Switch to alert box 
alertbox = driver.switch_to.alert
print(alertbox.text)
time.sleep(3)

# # To click on Cancel or dismiss
# alertbox.dismiss()
# time.sleep(3)

# # To click on OK
# alertbox.accept()
# time.sleep(3)

# To enter the text in prompt 
alertbox.send_keys("Hi this is sample")
alertbox.accept()
time.sleep(3)