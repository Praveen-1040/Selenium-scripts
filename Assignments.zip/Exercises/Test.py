from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.maximize_window()

username = "standard_user"
password = "secret_sauce"

login_url = "https://saucedemo.com/"
driver.get(login_url)

try:
    # Wait until username field is present
    username_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "user-name"))
    )
    
    password_field = driver.find_element(By.ID, "password")
    
    username_field.send_keys(username)
    password_field.send_keys(password)
    
    login_button = driver.find_element(By.ID, "login-button")
    
    # Check if the login button is enabled
    assert not login_button.get_attribute("disabled")
    
    login_button.click()
    
    # Wait until success page is loaded
    success_page = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, ".title"))
    )
    
    assert success_page.text == "Products" 
    print("Login successful, products page loaded.")
    
except Exception as e:
    print(f"An error occurred: Not the required page")

finally:
    # Optionally add a sleep to see the result before closing
    import time
    time.sleep(3)  # Wait for 3 seconds
    driver.quit()  # Close the browser
