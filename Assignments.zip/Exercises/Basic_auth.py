import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()

username = "admin"
password = "admin"
url1 = "https://admin:admin@the-internet.herokuapp.com/basic_auth"


# https://username:password@domain/path
driver.get(url1)

time.sleep(5)