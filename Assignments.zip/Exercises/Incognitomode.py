from selenium.webdriver.chrome.options import Options
from selenium import webdriver
import time

chrome_options = Options()
chrome_options.add_argument("--incognito")

driver = webdriver.Chrome(options=chrome_options)
driver.maximize_window()
driver.get("https://www.google.com")
time.sleep(10)