from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from openpyxl import load_workbook

wb = load_workbook("testdata.xlsx")
sheet = wb.active
driver = webdriver.Chrome()
driver.maximize_window()

for row in sheet.iter_rows(min_row=2,max_row=sheet.max_row,values_only=True):
    username = row[0]
    password = row[1]

    driver.get("https://www.saucedemo.com/v1/")
    time.sleep(10)
    driver.find_element(By.ID,value="user-name").send_keys(username)
    driver.find_element(By.ID,value="password").send_keys(password)
    driver.find_element(By.ID,value="login-button").click()
    time.sleep(10)

    driver.find_element(By.XPATH,value="//button[normalize-space()='Open Menu']").click()
    time.sleep(10)
    driver.find_element(By.XPATH,value="//a[@id='logout_sidebar_link']").click()
    time.sleep(10)

driver.quit()
    


