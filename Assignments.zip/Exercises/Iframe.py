import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://the-internet.herokuapp.com/iframe"
driver.get(url1)

# ## Entering into IFRAME
# #Accessing IFRAME
# iframe = driver.find_element(By.ID,value="mce_0_ifr")
# driver.switch_to.frame(iframe)

# # Wait for the text element to be interactable
# time.sleep(1)

# text_element = driver.find_element(By.ID,value="tinymce")
# text_element.clear()
# text_element.send_keys("This is sample")

# time.sleep(5)

## Exiting from IFRAME 
# driver.switch_to.default_content()
selenium_element = driver.find_element(By.TAG_NAME,"a")
href = selenium_element.get_attribute('href')
driver.execute_script(f"window.open('{href}','_blank')")
driver.get(href)
time.sleep(5)