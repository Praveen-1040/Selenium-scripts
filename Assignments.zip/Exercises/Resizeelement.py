import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

driver = webdriver.Chrome()
driver.maximize_window()
url1 = "https://demo.automationtesting.in/Resizable.html"
driver.get(url1)



initial_element = driver.find_element(By.XPATH,value="//div[@class='ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se']")
initial_element_size = driver.find_element(By.XPATH,value="//div[@id='resizable']")

initial_size = initial_element_size.size
print(initial_size)
time.sleep(5)

actions = ActionChains(driver)
actions.click_and_hold(initial_element).move_by_offset(200,200).release().perform()

time.sleep(5)
final_element_size = initial_element_size.size
print(final_element_size)
time.sleep(5)