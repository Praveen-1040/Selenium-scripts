import requests 
from selenium import webdriver
from selenium.webdriver.common.by import By
import time


driver = webdriver.Chrome()
driver.maximize_window()
login_url = "https://jqueryui.com/"
driver.get(login_url)


time.sleep(10)
all_links = driver.find_elements(By.TAG_NAME,value="a")
print(len(all_links))

for links in all_links:
    href = links.get_attribute("href")
    if href:
        try: 
            response = requests.get(href)
            if response.status_code>=400:
                print(f"broken links are: '{response.status_code}'and the link is '{href}'")
        except requests.exceptions.RequestException as e:
            print(f"Error in accessing : '{href}'")

driver.quit()                             
    